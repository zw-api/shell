:<<EOF
免责声明:
本脚本由本人[作文]编写，仅供学习和研究之用
本人不保证脚本的准确性及安全性
在使用过程中，您应自行承担所有风险，包括但不限于数据丢失、系统损坏或其他潜在问题。
EOF



clear
sleep 1s
echo "使用公告"
echo "执行此文件后请输入sh 1.sh"
sleep 1.5s
echo "正在初始化"
cd 1/sh
sh /storage/emulated/0/sh/1/mt/rish
echo "初始化失败"