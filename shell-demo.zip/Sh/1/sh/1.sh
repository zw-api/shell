#!/bin/bash


:<<EOF
免责声明:
本脚本由本人[作文]编写，仅供学习和研究之用
本人不保证脚本的准确性及安全性
在使用过程中，您应自行承担所有风险，包括但不限于数据丢失、系统损坏或其他潜在问题。
EOF




clear
sleep 0.3s

echo "\033[31m  作文sh  \033[0m"
sleep 0.7s
echo -e "\033[35m  指尖点燃烟草--曾经誓言作废  \033[0m"


echo -e "\033[40;37m 欢迎使用作文sh \033[0m"
sleep 0.5
echo -e "\033[40;37m 感谢您的使用 \033[0m"
sleep 0.5



echo -e "\033[34m  时间:  \033[0m"
date "+%Y年%H时%M分%S秒"
sleep 0.8

#-----以上为初始化介绍-----







#---循环
while :
do
echo ""
#---循环



#-----以下为功能菜单-----
echo -e "\033[34m -----功能菜单----- \033[0m"
echo "1.上色必备."
echo "2.读取设备信息."
echo "3.广角pak."
echo "4.四服清残留."
echo "5.管理路径."
echo "6.一键创建文件夹."
echo "7.清屏."
echo "8.调用adb权限解决进程问题."
echo "9.低亮度+广角."
echo "10.退出脚本."
echo -e "\033[34m -----功能菜单----- \033[0m"



sleep 0.5s 


echo "\033[31m请输入对应数字\033[0m"
  read key
  case $key in
#-----以上为功能菜单-----
 
  
   
    
     
      
       
        
         
         
         
         
         
         
         
          
           
            
             
#-----以下为上色必备菜单-----         
1)
  echo -e "\033[34m ---上色必备功能菜单--- \033[0m"
  echo "1.obb."
  echo "2.修复包."
  echo "3.一键导入obb+修复包."
  echo "4.删除闪退."
  echo "5.快速更新."
  echo "6.启动pubg."
  echo "7.返回上一级."
  echo "8.退出脚本."
  echo -e "\033[34m ---上色必备功能菜单--- \033[0m"
  sleep 0.5
  echo ""
  echo "\033[31m 请输入对应数字\033[0m"
  read d
  case $d in
  
  
  
   1)
   cp /storage/emulated/0/1/obb/main.18325.com.tencent.ig.obb /storage/emulated/0/Android/obb/com.tencent.ig/
   echo "导入obb成功" ;;
   
  
    
   2)
   cp /storage/emulated/0/1/631/files /storage/emulated/0/Android/data/com.tencent.ig/
   echo "导入修复包成功" ;;
   
  
   
   3)
    cp /storage/emulated/0/1/obb/main.18325.com.tencent.ig.obb /storage/emulated/0/Android/obb/com.tencent.ig/
    sleep 0.5s
    cp /storage/emulated/0/1/631/files /storage/emulated/0/Android/data/com.tencent.ig/
    echo "一键导入成功" ;;
     
       
   4)
   rm -f /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_es3shader_3.0.0.18325.pak
   echo "删除闪退文件成功" ;;
   
  
    
   5)
   cp /storage/emulated/0/1/631/files /storage/emulated/0/Android/data/com.tencent.ig/
   rm -f /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_es3shader_3.0.0.18325.pak
   echo "一键快速更新成功" ;;
     
   
   
   6)
     am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
     echo "启动成功 未启动请手动打开" ;;
   
   
   
   7) 
   sh /storage/emulated/0/sh/1/sh/1.sh 
   clear
   echo "返回上级菜单成功" 
   clear
   ;;
   
   
   8)
   echo "您已退出"
   exit
   esac
   ;;
#-----以上为上色必备菜单-----  




























   
2)
  echo -e "\033[33m读取设备信息 \033[0m"
  sleep 0.5
  echo -n "时间："
  date "+%Y年%H时%M分%S秒"
  sleep 0.5
  echo -n "设备："
  getprop ro.product.brand
  sleep 0.5
  echo -n "设备类型："
  getprop ro.product.model
  sleep 0.5
  echo -n "内核版本: "
  uname -r
  sleep 0.5
  echo -n "安卓版本: "
  getprop ro.build.version.release
  sleep 0.6s
  echo "已读取成功" ;;
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
3) 
  echo -e "\033[34m -----pak功能菜单----- \033[0m"
  echo "1.蓝圈."
  echo "2.大厅."
  echo "3.返回."
  echo "4.退出."
  echo -e "\033[34m -----pak功能菜单----- \033[0m"
  sleep 0.5
  echo "\033[31m 请输入对应数字\033[0m"
  read ls
  case $ls in
  
  
       1)
       rm -f /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/map_tplan_3.1.0.18525.pak
       cp /storage/emulated/0/1/pak/1/map_tplan_3.1.0.18525.pak /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/
       echo "蓝圈执行成功" 
       ;;
       
       
       
       2)
       rm -f /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/map_tplan_3.1.0.18525.pak
       cp /storage/emulated/0/1/pak/2/map_tplan_3.1.0.18525.pak /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/
       echo "大厅执行成功" ;;
       
       
       
       
       
       3)
       sh /storage/emulated/0/sh/1/sh/1.sh
       clear
       echo "返回上级菜单成功" 
       clear
       ;;
       
       
       
       4)
       echo "退出成功" 
       exit
       esac
       ;;
  
 
 
 
 
 
 
 
 
 
 
 
 













 
 
 
 
   
    
     
       
4)
  echo "\033[31m  ---正在清理中---\033[0m"
am force-stop com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.ig/files /storage/emulated/0/Android/data/com.tencent.ig/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/*
mv /storage/emulated/0/Android/data/com.tencent.ig/.files /storage/emulated/0/Android/data/com.tencent.ig/files

#mv /data/data/com.tencent.ig/lib /data/data/com.tencent.ig/.lib
#rm -rf /data/data/com.tencent.ig/*
#mv /data/data/com.tencent.ig/.lib /data/data/com.tencent.ig/lib

mv /storage/emulated/0/Android/data/com.tencent.ig /storage/emulated/0/Android/data/com.tencent.ig1
pm clear com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig1 /storage/emulated/0/Android/data/com.tencent.ig
echo 正在清理...
am force-stop com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files /storage/emulated/0/Android/data/com.pubg.krmobile/.files
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/.files /storage/emulated/0/Android/data/com.pubg.krmobile/files

#mv /data/data/com.pubg.krmobile/lib /data/data/com.pubg.krmobile/.lib
#rm -rf /data/data/com.pubg.krmobile/*
#mv /data/data/com.pubg.krmobile/.lib /data/data/com.pubg.krmobile/lib

mv /storage/emulated/0/Android/data/com.pubg.krmobile /storage/emulated/0/Android/data/com.pubg.krmobile1
pm clear com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile1 /storage/emulated/0/Android/data/com.pubg.krmobile

echo 正在清理...
am force-stop com.tencent.igce
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game /storage/emulated/0/Android/data/com.tencent.igce/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.igce/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.igce/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/files/*
mv /storage/emulated/0/Android/data/com.tencent.igce/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.igce/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.igce/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.igce/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.igce/files /storage/emulated/0/Android/data/com.tencent.igce/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.igce/*
mv /storage/emulated/0/Android/data/com.tencent.igce/.files /storage/emulated/0/Android/data/com.tencent.igce/files

#mv /data/data/com.tencent.igce/lib /data/data/com.tencent.igce/.lib
#rm -rf /data/data/com.tencent.igce/*
#mv /data/data/com.tencent.igce/.lib /data/data/com.tencent.igce/lib

mv /storage/emulated/0/Android/data/com.tencent.igce /storage/emulated/0/Android/data/com.tencent.igce1
pm clear com.tencent.igce
mv /storage/emulated/0/Android/data/com.tencent.igce1 /storage/emulated/0/Android/data/com.tencent.igce
echo 正在清理...
am force-stop com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files /storage/emulated/0/Android/data/com.vng.pubgmobile/.files
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/.files /storage/emulated/0/Android/data/com.vng.pubgmobile/files

#mv /data/data/com.vng.pubgmobile/lib /data/data/com.vng.pubgmobile/.lib
#rm -rf /data/data/com.vng.pubgmobile/*
#mv /data/data/com.vng.pubgmobile/.lib /data/data/com.vng.pubgmobile/lib

mv /storage/emulated/0/Android/data/com.vng.pubgmobile /storage/emulated/0/Android/data/com.vng.pubgmobile1
pm clear com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile1 /storage/emulated/0/Android/data/com.vng.pubgmobile
echo "\033[31m  ---清除数据异常日志成功---  \033[0m"
  ;;
  
  
  
  
  
  
  
  
  






















  
  
  
  
5)
  echo "1.检测路径."
  echo "2.跳转路径."
  echo "3.返回菜单."
  echo "4.退出脚本"
  echo "请选择"
  read a
  case $a in
  
      1)
      echo "当前路径为:"
      pwd
      ;;
      
      2)
      echo "请输入您想跳转的路径"
      read b
      cd $b
      echo "跳转成功"
      echo "当前路径为:"
      pwd
      ;;
      
      3)
      sh /storage/emulated/0/sh/1/sh/1.sh
      clear 
      echo "返回成功"
      clear
      ;;
      
      4)
      echo "您已退出"
      exit
      esac
      ;;
      
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


6)
  DIR="/storage/emulated/0/1"
 
  if [ -d "$DIR" ]; then
    echo "文件夹存在：$DIR"
  else
    echo "文件夹不存在：$DIR"
    cd /storage/emulated/0/
    mkdir 1
    echo "已自动在目录下创建文件夹"
    cd /storage/emulated/0/1/
    mkdir 631
    mkdir obb
    mkdir pak
    cd pak
    mkdir 1
    mkdir 2
    cd /storage/emulated/0/
    cd 1
    mkdir sav
  fi
  ;;
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

7)
  clear
  echo "清屏成功" ;;
  
  






























8)
  echo "请确保您的adb权限已获得"
  sleep 1s
  /system/bin/device_config set_sync_disabled_for_tests persistent; /system/bin/device_config put activity_manager max_phantom_processes 2147483647
  echo "执行成功" ;;
































9)
  echo "正在执行"
  cp /storage/emulated/0/1/sav/Active.sav /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/
  echo "执行成功"
  ;;
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
10) 
  echo -e "\033[34m 您已退出 \033[0m"
  echo "\033[31m 祝您使用愉快\033[0m"
  exit
  esac
  done
  
  
  
  
:<<EOF
免责声明:
本脚本由本人[作文]编写，仅供学习和研究之用
本人不保证脚本的准确性及安全性
在使用过程中，您应自行承担所有风险，包括但不限于数据丢失、系统损坏或其他潜在问题。
EOF